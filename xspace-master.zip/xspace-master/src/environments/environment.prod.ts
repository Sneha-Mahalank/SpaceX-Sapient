export const environment = {
  production: true,
  BASE_API_URL: 'https://api.spaceXdata.com/v3/'
};
